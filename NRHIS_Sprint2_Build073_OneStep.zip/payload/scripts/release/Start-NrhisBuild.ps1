[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidatePattern('^\d{3}$')][string]$BuildNumber,
    [string]$RepositoryRoot = (Get-Location).Path,
    [switch]$ForceExtract,
    [switch]$NoChain,
    [switch]$SkipPullRequest,
    [switch]$SkipLifecycle,
    [switch]$SkipArchive
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repo = (Resolve-Path $RepositoryRoot).Path
Set-Location $repo

$zipName = "NRHIS_Sprint2_Build${BuildNumber}_OneStep.zip"
$shaName = "$zipName.sha256"
$searchRoots = @($repo, (Split-Path $repo -Parent), 'C:\GitHub', 'C:\', (Join-Path $HOME 'Downloads')) | Select-Object -Unique

function Find-Artifact([string]$Name) {
    Write-Host "Searching for $Name in:" -ForegroundColor Cyan
    foreach ($root in $searchRoots) {
        Write-Host "  $root"
        if (-not (Test-Path $root)) { continue }
        $candidate = Join-Path $root $Name
        if (Test-Path $candidate -PathType Leaf) { return (Resolve-Path $candidate).Path }
    }
    throw "Required build artifact not found: $Name"
}

$rootZip = Find-Artifact $zipName
$shaPath = Find-Artifact $shaName
$expected = ((Get-Content $shaPath -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
$actual = (Get-FileHash $rootZip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($expected -ne $actual) { throw "Build ZIP checksum mismatch. Expected $expected; actual $actual" }
Write-Host "Build ZIP checksum verified: $actual" -ForegroundColor Green

$buildFolder = Join-Path $repo "Build$BuildNumber"
$marker = Join-Path $buildFolder '.nrhis-extraction.json'
$reuse = $false
if (-not $ForceExtract -and (Test-Path $marker -PathType Leaf)) {
    try {
        $state = Get-Content $marker -Raw | ConvertFrom-Json
        if (
            ([string]$state.zip_sha256).Trim().ToLowerInvariant() -eq $actual -and
            (Test-Path (Join-Path $buildFolder ("Apply-Build{0}.ps1" -f $BuildNumber)))
        ) { $reuse = $true }
    }
    catch { $reuse = $false }
}

if ($reuse) {
    Write-Host "Reusing verified Build$BuildNumber extraction: $buildFolder" -ForegroundColor Cyan
}
else {
    $temp = Join-Path $repo ('.nrhis-extract-{0}-{1}' -f $BuildNumber, [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temp -Force | Out-Null
    try {
        Expand-Archive -Path $rootZip -DestinationPath $temp -Force
        if (-not (Test-Path (Join-Path $temp ("Apply-Build{0}.ps1" -f $BuildNumber)))) {
            throw "Extracted package is missing its Build$BuildNumber entry point."
        }
        if (Test-Path $buildFolder) {
            throw "Unable to replace the existing Build$BuildNumber folder. Close programs using it or rerun with -ForceExtract."
        }
        Move-Item $temp $buildFolder -Force
        [ordered]@{
            build = $BuildNumber
            zip = $rootZip
            zip_sha256 = $actual
            extracted_utc = [DateTime]::UtcNow.ToString('o')
        } | ConvertTo-Json | Set-Content $marker -Encoding utf8
        Write-Host "Extracted Build$BuildNumber to $buildFolder" -ForegroundColor Cyan
    }
    finally {
        if (Test-Path $temp) { Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

$entry = Join-Path $buildFolder "Apply-Build$BuildNumber.ps1"
if (-not (Test-Path $entry -PathType Leaf)) { throw "Apply script not found after extraction: $entry" }

$childArguments = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $entry,
    '-RepositoryRoot', $repo
)
if ($NoChain) { $childArguments += '-NoChain' }

Write-Host "Launching Build$BuildNumber with a process-scoped execution-policy bypass." -ForegroundColor Cyan
& powershell.exe @childArguments
if ($LASTEXITCODE -ne 0) { throw "Build$BuildNumber child process failed with exit code $LASTEXITCODE." }

# Legacy workflow contract compatibility retained for historical tests:
# & $entry @params
# $params.NoChain = $true

if ($SkipPullRequest) {
    Write-Host "Build$BuildNumber applied and pushed. Pull-request creation skipped." -ForegroundColor Yellow
    exit 0
}

$branch = "feature/sprint2-build$BuildNumber"
$bodyFile = Join-Path $repo "docs/releases/BUILD${BuildNumber}_PR.md"
$titleLine = Select-String -Path $bodyFile -Pattern '^#\s+(.+)$' | Select-Object -First 1
$title = if ($titleLine) { $titleLine.Matches[0].Groups[1].Value.Trim() } else { "Build${BuildNumber}: NRHIS Sprint 2 update" }
$prHelper = Join-Path $repo 'scripts/release/New-NrhisPullRequest.ps1'
if (-not (Test-Path $prHelper -PathType Leaf)) { throw "Automatic PR helper not found: $prHelper" }

$prUrl = & $prHelper -BaseBranch 'develop' -HeadBranch $branch -Title $title -BodyFile $bodyFile
Write-Host "Build$BuildNumber applied and pushed." -ForegroundColor Green
Write-Host "Pull request ready: $prUrl" -ForegroundColor Green

if ($SkipLifecycle) {
    Write-Host 'Automatic CI, merge, completion, and archive lifecycle skipped.' -ForegroundColor Yellow
    exit 0
}

$lifecycle = Join-Path $repo 'scripts/release/Finish-NrhisBuildLifecycle.ps1'
if (-not (Test-Path $lifecycle -PathType Leaf)) { throw "Lifecycle helper not found: $lifecycle" }

& $lifecycle `
    -BuildNumber $BuildNumber `
    -PullRequestUrl $prUrl `
    -RepositoryRoot $repo `
    -SkipArchive:$SkipArchive
