[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidatePattern('^\d{3}$')][string]$BuildNumber,
    [string]$RepositoryRoot = (Get-Location).Path,
    [switch]$SkipPullRequest
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repo = (Resolve-Path $RepositoryRoot).Path
Set-Location $repo

$zipName = "NRHIS_Sprint2_Build${BuildNumber}_OneStep.zip"
$shaName = "$zipName.sha256"
$searchRoots = @($repo, (Split-Path $repo -Parent), 'C:\GitHub', 'C:\', (Join-Path $HOME 'Downloads')) | Select-Object -Unique

function Find-Artifact([string]$Name) {
    Write-Host "Searching for $Name in:" -ForegroundColor Cyan
    foreach ($root in $searchRoots) {
        Write-Host "  $root"
        if (-not (Test-Path $root)) { continue }
        $candidate = Join-Path $root $Name
        if (Test-Path $candidate -PathType Leaf) { return (Resolve-Path $candidate).Path }
    }
    throw "Required build artifact not found: $Name"
}

$zipPath = Find-Artifact $zipName
$shaPath = Find-Artifact $shaName
$expected = ((Get-Content $shaPath -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
$actual = (Get-FileHash $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($expected -ne $actual) { throw "Build ZIP checksum mismatch. Expected $expected; actual $actual" }
Write-Host "Build ZIP checksum verified: $actual" -ForegroundColor Green

$buildRoot = Join-Path $repo "Build$BuildNumber"
if (Test-Path $buildRoot) { Remove-Item $buildRoot -Recurse -Force }
New-Item -ItemType Directory -Path $buildRoot -Force | Out-Null
Expand-Archive -Path $zipPath -DestinationPath $buildRoot -Force
Write-Host "Extracted Build$BuildNumber to $buildRoot" -ForegroundColor Green

$entry = Join-Path $buildRoot "Apply-Build$BuildNumber.ps1"
if (-not (Test-Path $entry -PathType Leaf)) { throw "Extracted package is missing its Build$BuildNumber entry point." }

Write-Host "Launching Build$BuildNumber with a process-scoped execution-policy bypass." -ForegroundColor Cyan
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $entry -RepositoryRoot $repo
if ($LASTEXITCODE -ne 0) { throw "Build$BuildNumber child process failed with exit code $LASTEXITCODE." }

if ($SkipPullRequest) {
    Write-Host "Build$BuildNumber applied and pushed. Pull-request creation skipped." -ForegroundColor Yellow
    exit 0
}

$branch = "feature/sprint2-build$BuildNumber"
$bodyFile = Join-Path $repo "docs/releases/BUILD${BuildNumber}_PR.md"
$titleLine = Select-String -Path $bodyFile -Pattern '^#\s+(.+)$' | Select-Object -First 1
$title = if ($titleLine) { $titleLine.Matches[0].Groups[1].Value.Trim() } else { "Build${BuildNumber}: NRHIS Sprint 2 update" }
$prHelper = Join-Path $repo 'scripts/release/New-NrhisPullRequest.ps1'
if (-not (Test-Path $prHelper -PathType Leaf)) { throw "Automatic PR helper not found: $prHelper" }

$prUrl = & $prHelper -Branch $branch -Base 'develop' -Title $title -BodyFile $bodyFile -RepositoryRoot $repo
Write-Host "Build$BuildNumber applied and pushed." -ForegroundColor Green
Write-Host "Pull request ready: $prUrl" -ForegroundColor Green
Write-Host 'Waiting for CI and merge into develop.' -ForegroundColor Yellow
