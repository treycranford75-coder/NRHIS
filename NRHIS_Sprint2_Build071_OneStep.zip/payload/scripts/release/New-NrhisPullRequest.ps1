[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Branch,
    [string]$Base = 'develop',
    [Parameter(Mandatory)][string]$Title,
    [Parameter(Mandatory)][string]$BodyFile,
    [string]$RepositoryRoot = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repo = (Resolve-Path $RepositoryRoot).Path
Set-Location $repo

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    throw 'GitHub CLI (gh) is required for automatic pull-request creation.'
}

& gh auth status 1>$null 2>$null
if ($LASTEXITCODE -ne 0) {
    throw 'GitHub CLI is not authenticated. Run: gh auth login'
}

if (-not (Test-Path $BodyFile -PathType Leaf)) {
    throw "Pull-request body file not found: $BodyFile"
}

$existing = & gh pr list `
    --head $Branch `
    --base $Base `
    --state open `
    --json url `
    --jq '.[0].url'

if ($LASTEXITCODE -ne 0) {
    throw 'Unable to query existing pull requests.'
}

if (-not [string]::IsNullOrWhiteSpace($existing)) {
    Write-Host "Existing pull request: $existing" -ForegroundColor Green
    return $existing.Trim()
}

$url = & gh pr create `
    --base $Base `
    --head $Branch `
    --title $Title `
    --body-file $BodyFile

if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($url)) {
    throw 'GitHub pull-request creation failed.'
}

$url = $url.Trim()
Write-Host "Pull request created: $url" -ForegroundColor Green
return $url
